OPTIONAL_FIELDS = [
    'tags', 'consumes', 'produces', 'schemes', 'security',
    'deprecated', 'operationId', 'externalDocs'
]
