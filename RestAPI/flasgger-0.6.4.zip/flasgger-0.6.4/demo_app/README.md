# demo app

```bash
python app.py
```

Runs a demo app with all the examples applications published

> NOTE: This demo app is intended to run on our demo server. For example code take a look at `examples` folder.
